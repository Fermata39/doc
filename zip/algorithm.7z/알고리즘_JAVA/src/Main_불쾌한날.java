import java.util.Scanner;

public class Main_�����ѳ� {
	int N;
	int [] h;
	int [] stack;//FA stack
	int sp;
	void push(int h) { stack[++sp] = h;	}
	int top() { return stack[sp]; }
	void pop() { sp--; }
	boolean empty() { return sp == 0; }
	int size() { return sp; }
	public static void main(String[] args) {
		Main_�����ѳ� m = new Main_�����ѳ�();
		m.InputData();
		System.out.println(m.solve());
	}
	long solve() {
		long cnt = 0;
		stack = new int [N + 10]; sp = 0;//stack initial
		for(int i=0;i<N;i++) {
			while(!empty() && (top() <= h[i])) pop();
			cnt += size();
			push(h[i]);
		}
		return cnt;
	}
	void InputData() {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		h = new int[N + 10];
		for(int i=0;i<N;i++) {
			h[i] = sc.nextInt();
		}
		sc.close();
	}
}
