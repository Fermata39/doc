//B1:������׷�
import java.util.Scanner;
import java.util.Stack;

public class Main_������׷� {
	int N;
	int [] h;
	class DATA{
		int h, pos;
		DATA(int h, int pos){ this.h=h; this.pos=pos;}
	}
	Scanner sc;
	public static void main(String[] args) {
		Main_������׷� m = new Main_������׷�();
		m.sc = new Scanner(System.in);
		while(true) {
			if(!m.InputData()) break;
			System.out.println(m.solve());
		}
		m.sc.close();
	}
	long solve() {
		Stack <DATA> stk = new Stack <DATA>();
		long maxarea = 0, area;
		for(int i=0;i<N;i++) {
			int pos = i;
			while(!stk.empty() && (stk.peek().h >= h[i])) {
				DATA tmp = stk.pop();
				area = (long)tmp.h * (i - tmp.pos); pos = tmp.pos;
				if(maxarea < area) maxarea = area;
			}
			stk.push(new DATA(h[i], pos));
		}
		while(!stk.empty()) {
			DATA tmp = stk.pop();
			area = (long)tmp.h * (N - tmp.pos);
			if(maxarea < area) maxarea = area;
		}
		return maxarea;
	}
	boolean InputData() {
		N = sc.nextInt();
		if(N == 0) return false;
		h = new int [N + 10];
		for(int i=0;i<N;i++) {
			h[i] = sc.nextInt();
		}
		return true;
	}
}
