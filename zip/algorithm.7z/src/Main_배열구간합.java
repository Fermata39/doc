import java.util.Scanner;

public class Main_�迭������ {
	int N, Q;
	int [] presum;
	int [] qs;
	int [] qe;
	public static void main(String[] args) {
		Main_�迭������ m = new Main_�迭������();
		m.inputdata();
		m.solve();
	}
	void solve() {
		for(int i=1;i<=Q;i++) {
			System.out.println(presum[qe[i]] - presum[qs[i]-1]);
		}
	}
	void inputdata() {
		Scanner in = new Scanner(System.in);
		N = in.nextInt(); Q = in.nextInt();
		presum = new int [N+2];
		for(int i=1;i<=N;i++) {
			presum[i] = presum[i-1] + in.nextInt();
		}
		qs = new int [Q+2]; qe = new int [Q+2];
		for(int i=1;i<=Q;i++) {
			qs[i]=in.nextInt(); qe[i]=in.nextInt();
		}
		in.close();
	}
}
