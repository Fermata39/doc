import java.util.Scanner;
import java.util.Stack;

public class Main_�����Ѽ�stack {
	int N;
	int [] h;
	public static void main(String[] args) {
		Main_�����Ѽ�stack m = new Main_�����Ѽ�stack();
		m.InputData();
		System.out.println(m.solve());
	}
	long solve() {
		Stack <Integer> stk = new Stack <Integer>();
		long cnt = 0;
		for(int i=0;i<N;i++) {
			while(!stk.empty() && (stk.peek() <= h[i])) stk.pop();
			cnt += stk.size();
			stk.push(h[i]);
		}
		return cnt;
	}
	void InputData() {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		h = new int[N + 10];
		for(int i=0;i<N;i++) {
			h[i] = sc.nextInt();
		}
		sc.close();
	}
}
