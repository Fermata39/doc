//B9:�ڿܼ����ذ��� �Ϲ�ťȰ��
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Scanner;
public class Main_�ڿܼ��Ϲ�ť {
	int N;
	char [][] map;
	int [][] visit;
	class DATA{
		int r, c;//����, ����
		DATA(int r, int c) { this.r=r; this.c=c; }
	}
	public static void main(String[] args) {
		Main_�ڿܼ��Ϲ�ť m = new Main_�ڿܼ��Ϲ�ť();
		m.InputData();
		System.out.println(m.BFS());
	}
	int BFS() {
		int dr[]= {-1, 1, 0, 0};
		int dc[]= {0, 0, -1, 1};
		visit = new int[N+2][N+2];//�ʱ�ȭ
		for(int i=1;i<=N;i++) {
			for(int j=1;j<=N;j++) {
				visit[i][j] = Integer.MAX_VALUE;
			}
		}
		Queue <DATA> que = new ArrayDeque <DATA>();
		que.offer(new DATA(1, 1));//������ġ ť�� ����
		visit[1][1] = map[1][1]-'0';
		while(!que.isEmpty()) {//�ݺ���
			DATA tmp = que.poll();
			for(int i=0;i<4;i++) {
				int nr=tmp.r+dr[i]; int nc=tmp.c+dc[i];
				if (!(('0'<=map[nr][nc])&&(map[nr][nc]<='9'))) continue;//�ѷ���
				if(visit[nr][nc] <= visit[tmp.r][tmp.c]+map[nr][nc]-'0') continue;//�������� �� ����
				visit[nr][nc] = visit[tmp.r][tmp.c]+map[nr][nc]-'0';
				que.offer(new DATA(nr, nc));
			}
		}
		return visit[N][N];
	}
	void InputData() {
		Scanner in = new Scanner(System.in);
		N = in.nextInt();
		map = new char [N+2][N+2];
		for(int i=1;i<=N;i++) {
			map[i] = (" "+in.next()+" ").toCharArray();
		}
		in.close();
	}
}
