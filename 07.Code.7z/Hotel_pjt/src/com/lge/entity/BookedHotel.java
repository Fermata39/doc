package com.lge.entity;

public class BookedHotel {

	private boolean canceled; // 취소 여부
	private Hotel hotel;

	public BookedHotel(Hotel hotel, boolean canceled) {
		this.hotel = hotel;
		this.canceled = canceled;
	}

	public void setCanceled(boolean canceled) {
		this.canceled = canceled;
	}

	public boolean getCanceled() {
		return this.canceled;
	}

	@Override
	public String toString() {
		return String.format("%-10s%-10s%-10s%-10s", this.hotel.getName(),
				this.hotel.getPrice(), this.hotel.getLocation(),
				this.getBookingStatus());
	}

	/**
	 * 호텔의 예약 상태를 String 객체로 반환한다.
	 * 
	 * @return 호텔의 예약 상태 (Booked or Canceled)
	 */
	public String getBookingStatus() {

		// TODO : 여기에 코드를 작성하시오
		if (hotel != null && canceled == true) {
			return "Booked";
		} else {
			return "Canceled";
		}
	}

	public String getName() {
		return hotel.getName();
	}

	public Hotel getHotel() {
		return hotel;
	}

}
