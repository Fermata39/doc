package com.lge.entity;


public class Hotel {
	private String name;	// 호텔 이름
	private int price;		// 호텔 가격
	private int location;	// 호텔 위치
	private int rooms;		// 호텔 잔여 방 개수
	
	public Hotel(String name, int price, int location, int rooms) {
		this.name = name;
		this.price = price;
		this.location = location;
		this.rooms = rooms;
	}
		
	public String getName() {
		return this.name;
	}
	
	public int getPrice() {
		return this.price;
	}
	
	public int getLocation() {
		return this.location;
	}
	
	public int getRooms() {
		return this.rooms;
	}
	
	/**
	 * 호텔의 잔여 방 개수를 하나 증가시킨다.
	 */
	public void increaseRooms() {
		this.rooms++;
	}
	
	/**
	 * 호텔의 잔여 방 개수를 하나 감소시킨다.
	 */
	public void decreaseRooms() {
		this.rooms--;
	}
	
	@Override
    public String toString() {
		return String.format("%-10s%-10s%-10s%-10s", this.name, this.price, this.location, printRooms());
    }	
	
	/**
	 * 현재 잔여 방 개수를 String 객체로 변환하여 반환하되 잔여 방 개수가 0인 경우 NO ROOMS를 반환한다.
	 * 
	 * @return String 객체로 변환된 현재 잔여 방 개수
	 */
	private String printRooms() {
		
		
		// TODO : 여기에 코드를 작성하시오
		String roomReturn = Integer.toString(this.rooms);
		
		if(this.rooms == 0){
			roomReturn = "NO ROOMS";
		}
		
		return roomReturn;	// 임시 코드이므로 구현 후 삭제 요망
	}

	/**
	 * 전달된 현재 위치에 대한 호텔의 근접도를 계산하여 반환한다.
	 * 
	 * @param curLoc
	 * 				현재 위치
	 * @return	계산된 호텔의 근접도
	 */
	public int getProximity(int curLoc) {
		
		
		// TODO : 여기에 코드를 작성하시오		
		
               
		return 0;	// 임시 코드이므로 구현 후 삭제 요망
	}	
}
