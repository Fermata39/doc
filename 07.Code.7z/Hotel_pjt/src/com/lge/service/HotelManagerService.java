package com.lge.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.lge.entity.BookedHotel;
import com.lge.entity.Hotel;
import com.lge.exception.AlreadyBookedException;
import com.lge.exception.AlreadyCanceledException;
import com.lge.exception.InvalidNumberException;

public class HotelManagerService {
	private ArrayList<Hotel> hotelList = new ArrayList<Hotel>(); // 전체 호텔 리스트
	private ArrayList<BookedHotel> myBookingList = new ArrayList<BookedHotel>(); // 내
																					// 예약
																					// 리스트
	private int curLoc; // 현재 위치

	/**
	 * 호텔매니저서비스 생성자
	 */
	public HotelManagerService() {
		initHotelList();
	}

	/**
	 * 호텔 리스트를 초기화 한다.
	 */
	public void initHotelList() {
		hotelList.add(new Hotel("A_Hotel", 100000, 5, 6));
		hotelList.add(new Hotel("B_Hotel", 150000, 3, 2));
		hotelList.add(new Hotel("C_Hotel", 120000, 25, 8));
		hotelList.add(new Hotel("D_Hotel", 200000, 15, 12));
		hotelList.add(new Hotel("E_Hotel", 170000, 8, 1));
		hotelList.add(new Hotel("F_Hotel", 90000, 21, 0));
		hotelList.add(new Hotel("G_Hotel", 160000, 15, 3));
		hotelList.add(new Hotel("H_Hotel", 220000, 17, 0));
		hotelList.add(new Hotel("I_Hotel", 300000, 12, 4));
		hotelList.add(new Hotel("J_Hotel", 130000, 11, 0));
		hotelList.add(new Hotel("K_Hotel", 270000, 10, 2));
		hotelList.add(new Hotel("L_Hotel", 140000, 14, 0));
		hotelList.add(new Hotel("M_Hotel", 250000, 23, 11));
		hotelList.add(new Hotel("N_Hotel", 100000, 25, 3));
		hotelList.add(new Hotel("O_Hotel", 130000, 16, 2));
		hotelList.add(new Hotel("P_Hotel", 210000, 24, 3));
		hotelList.add(new Hotel("Q_Hotel", 110000, 7, 1));
		hotelList.add(new Hotel("R_Hotel", 180000, 1, 2));
		hotelList.add(new Hotel("S_Hotel", 160000, 2, 10));
		hotelList.add(new Hotel("T_Hotel", 190000, 5, 3));

		// 내 예약 리스트에 G_Hotel, C_Hotel, S_Hotel을 미리 추가한다.
		Hotel g_hotel = hotelList.get(6);
		Hotel c_hotel = hotelList.get(2);
		Hotel s_hotel = hotelList.get(18);

		// G_Hotel과 C_Hotel은 예약 취소 상태로 생성
		myBookingList.add(new BookedHotel(g_hotel, true));
		myBookingList.add(new BookedHotel(c_hotel, true));
		myBookingList.add(new BookedHotel(s_hotel, false));

		s_hotel.decreaseRooms();
	}

	/**
	 * 현재 위치를 설정한다.
	 * 
	 * @param location
	 *            입력된 현재 위치
	 */
	public void setCurrentLocation(int location) {
		this.curLoc = location;
	}

	/**
	 * 호텔의 가격으로 오름차순 정렬하고 가격이 같을 경우 호텔의 이름으로 오름차순 정렬하는 Comparator
	 */
	private Comparator<Hotel> sortingByPriceAndName = new Comparator<Hotel>() {
		@Override
		public int compare(Hotel o1, Hotel o2) {

			// TODO : 여기에 코드를 작성하시오
			if (o1.getPrice() > o2.getPrice()) {
				return 1;
			} else if (o1.getPrice() == o2.getPrice()) {
				return o1.getName().compareTo(o2.getName());
			}

			return 0; // 임시 코드이므로 구현 후 삭제 요망
		}
	};

	/**
	 * 예약 상태가 Booked인 호텔을 Canceled인 호텔보다 먼저 오도록 정렬하고 예약 상태가 동일할 경우 호텔의 이름으로 오름차순
	 * 정렬하는 Comparator
	 */
	private Comparator<BookedHotel> sortingByStatusAndName = new Comparator<BookedHotel>() {
		@Override
		public int compare(BookedHotel o1, BookedHotel o2) {

			// TODO : 여기에 코드를 작성하시오
			if (o1.getBookingStatus().equals("Booked")) {
				return o1.getBookingStatus().compareTo(o2.getBookingStatus());
			} else {
				return o1.getName().compareTo(o2.getName());
			}
		}
	};

	/**
	 * 호텔의 근접도로 오름차순 정렬하고 근접도가 같을 경우 호텔의 가격으로 정렬하는 Comparator
	 */
	private Comparator<Hotel> sortingByProximityAndPrice = new Comparator<Hotel>() {
		@Override
		public int compare(Hotel o1, Hotel o2) {

			// TODO : 여기에 코드를 작성하시오
			if (o1.getLocation() == o2.getLocation()) {
				return o1.getPrice() > o2.getPrice() ? 1 : -1;
			}
			return 0; // 임시 코드이므로 구현 후 삭제 요망
		}
	};

	/**
	 * 가격과 이름으로 정렬된 호텔 리스트를 반환한다.
	 * 
	 * @return 정렬된 호텔 리스트
	 */
	public List<Hotel> getHotelList() {
		Collections.sort(hotelList, sortingByPriceAndName);

		return hotelList;
	}

	/**
	 * 현재 내 예약 리스트를 가격으로 정렬하고 가격이 같은 경우 호텔 이름으로 정렬하여 반환한다.
	 * 
	 * @return 정렬된 내 예약 리스트
	 */
	public List<BookedHotel> getMyBookingList() {
		Collections.sort(myBookingList, sortingByStatusAndName);

		return myBookingList;
	}

	/**
	 * 현재 위치에 이웃한 호텔의 리스트를 근접도와 가격으로 오름차순 정렬하여 반환한다.
	 * 
	 * @return 정렬된 현재 위치에 이웃한 호텔 리스트
	 * @throws InvalidNumberException
	 *             전달된 현재 위치가 1~25 범위를 벗어날 경우 예외를 발생시킨다.
	 */
	public List<Hotel> getHotelListNearMyLoc() throws InvalidNumberException {
		List<Hotel> result = new ArrayList<Hotel>();

		// TODO : 여기에 코드를 작성하시오
		result = hotelList;
		for (int i = 0; i < result.size(); i++) {
			if (result.get(i).getLocation() < 1
					|| result.get(i).getLocation() > 25) {
				throw new InvalidNumberException();
			}
		}

		Collections.sort(result, sortingByProximityAndPrice);

		return result;
	}

	/**
	 * 전달된 호텔에 대하여 예약을 진행한다.
	 * 
	 * @param hotel
	 *            전달된 호텔 객체
	 * @throws AlreadyBookedException
	 *             전달된 호텔이 이미 예약 리스트에 있는 경우 예외를 발생시킨다.
	 */
	public void bookHotel(Hotel hotel) throws AlreadyBookedException {

		// TODO : 여기에 코드를 작성하시오

		for (BookedHotel r : myBookingList) {
			if (hotel.getName().equals(r.getHotel().getName())) {
				throw new AlreadyBookedException();
			}
		}

		myBookingList.add(new BookedHotel(hotel, true));

		System.out.println("\n:: Booking completed for " + hotel.getName()
				+ "\n");
	}

	/**
	 * 입력받은 호텔에 대해 예약 취소를 진행한다.
	 * 
	 * @param index
	 *            선택된 호텔의 index
	 * @throws InvalidNumberException
	 *             선택된 호텔이 예약 리스트에 없는 경우 예외를 발생시킨다.
	 * @throws AlreadyCanceledException
	 *             선택된 호텔이 이미 취소된 호텔인 경우 에외를 발생시킨다.
	 */
	public void cancelBooking(int index) throws InvalidNumberException,
			AlreadyCanceledException {
		// TODO : 필요한 경우 여기에 코드를 작성하시오

		BookedHotel selectedHotel = myBookingList.get(index - 1);

		// TODO : 여기에 코드를 작성하시오

		if (selectedHotel == null) {
			throw new InvalidNumberException();
		}

		if (selectedHotel.getBookingStatus().equals("Canceled")) {
			throw new AlreadyCanceledException();
		}

		// myBookingList.remove(selectedHotel);
		selectedHotel.setCanceled(false);

		System.out.println("\n:: Cancel completed for "
				+ selectedHotel.getName() + "\n");
	}
}
