package com.lge.util;

import java.util.Scanner;

/**
 * LG Electronics Software Engineer Test
 * 
 * 키보드 입력과 관련된 다양한 API를 제공한다.
 * 
 * @author MTec
 * @version 1.0
 * 
 */
public class KeyboardUtil {

    /**
     * 키보드로 정수를 입력 받는다.
     * 
     * @return 입력받은 정수
     * @throws InputMismatchException
     *             정수가 아닌 임의의 값이 입력되었을 경우 발생
     */
    public static int inputNumber() {

        return new Scanner(System.in).nextInt();
    }

    /**
     * 키보드로 정수를 입력 받는다.
     * 
     * @param cursor
     *            화면에 보여줄 문자열
     * @return 입력받은 정수
     */
    public static int inputNumber(String cursor) {

        System.out.print(cursor);
        return inputNumber();
    }

    /**
     * 키보드로 한줄의 스트링값을 입력 받는다.(중간에 공백도 포함하여 입력받음)
     * 
     * @return 입력받은 문자열
     */
    public static String inputString() {
        return new Scanner(System.in).nextLine();
    }

    /**
     * 키보드로 한줄의 스트링값을 입력 받는다.(중간에 공백도 포함하여 입력받음)
     * 
     * @param cursor
     *            화면에 보여줄 문자열
     * @return 입력받은 문자열
     */
    public static String inputString(String cursor) {

        System.out.print(cursor);
        return inputString();
    }

    /**
     * 키보드로 실수를 입력 받는다.
     * 
     * @return 입력받은 실수
     */
    public static double inputFloat() {
        return new Scanner(System.in).nextDouble();
    }

    /**
     * 키보드로 실수를 입력 받는다.
     * 
     * @param cursor
     *            화면에 보여줄 문자열
     * @return 입력받은 실수
     */
    public static double inputFloat(String cursor) {
        System.out.print(cursor);
        return inputFloat();
    }

}
