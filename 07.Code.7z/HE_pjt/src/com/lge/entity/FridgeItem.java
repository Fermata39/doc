package com.lge.entity;

public class FridgeItem {
	/**
	 * 아이템 이름 
	 */
	private String mName;
	
	/**
	 * 수량 
	 */
	private int mQuantity;
	
	public String getName() {
		return mName;
	}
	public void setName(String name) {
		this.mName = name;
	}
	public int getQuantity() {
		return mQuantity;
	}
	public void setQuantity(int quantity) {
		this.mQuantity = quantity;
	}	
	
}
