package com.lge.entity;

import com.lge.util.KeyboardUtil;

public class Television extends HomeAppliance {

	public static final String TYPE_STRING = Television.class.getSimpleName();

	private int mChannel = 0; // TV 채널 번호
	int pChannel = 0;

	public Television(int no) {
		super(no);
	}

	@Override
	public String getStatus() {
		String status = "Channel: 0";

		// TODO TV의 상태를 출력하는 코드를 작성하시오

		if (mChannel >= 0) {
			status = Integer.toString(mChannel);
			pChannel = Integer.parseInt(status);
		} else {
			status = Integer.toString(pChannel);
		}

		String res = String.format("%-8s%-15s%-20s", super.mNumber,
				TYPE_STRING, status);

		return res;
	}

	@Override
	public String readUserInput() {
		return KeyboardUtil.inputString("> Channel : ");
	}

	@Override
	public boolean control(String command) {
		// TODO TV 제어를 실행하는 코드를 작성하시오

		if (command != null) {
			mChannel = Integer.parseInt(command);

			if (mChannel < 0) {
				return false;
			}
			return true;
		}
		return false;
	}
}
