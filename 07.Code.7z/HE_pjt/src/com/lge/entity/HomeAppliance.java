package com.lge.entity;

/**
 * 가전기기 추상 클래스 
 *
 */
public abstract class HomeAppliance {
	
	protected int mNumber; //가전기기 번호 
	
	public HomeAppliance(int no) { 
		mNumber = no;
	}
	
	/**
	 * 번호를 리턴 
	 * @return 가전기기 번호 
	 */
	public int getNumber() { 
		return mNumber;
	}
	
	/**
	 * 가전기기 상태를 가져온다 
	 * @return 가전기기 상태 문자열 
	 */
	public abstract String getStatus();
	
	/**
	 * 사용자 input을 받는다. 
	 * @return 사용자에 입력받은 명령 
	 */
	public abstract String readUserInput();
	
	/**
	 * 가전기기를 제어한다. 
	 * @return 제어 성공 여부 
	 */
	public abstract boolean control(String command);
	
}
