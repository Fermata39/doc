package com.lge.entity;

import java.util.ArrayList;
import java.util.List;

import com.lge.util.KeyboardUtil;

public class Fridge extends HomeAppliance {

	public static final String TYPE_STRING = Fridge.class.getSimpleName();

	private List<FridgeItem> mItems; // 냉장고에 저장된 물건 목록

	public Fridge(int no) {
		super(no);
		mItems = new ArrayList<FridgeItem>();
	}

	@Override
	public String getStatus() {
		String contained = "Nothing";
		ArrayList<String> containedlist = new ArrayList<String>();

		// TODO 냉장고의 상태를 출력하는 코드를 작성하시오

		// System.out.println("!mItems size: " + mItems.size());
		String res = null;

		if (mItems.size() == 0) {
			res = String.format("%-8s%-15s%-20s", super.mNumber, TYPE_STRING,
					contained);
		} else {

			for (int i = 0; i < mItems.size(); i++) {
				containedlist.add(mItems.get(i).getName() + ":"
						+ mItems.get(i).getQuantity());
			}
			res = String.format("%-8s%-15s%-20s", super.mNumber, TYPE_STRING,
					containedlist);
		}

		// String res = String.format("%-8s%-15s%-20s", super.mNumber,
		// TYPE_STRING, contained);

		return res;
	}

	@Override
	public String readUserInput() {
		String command1 = KeyboardUtil.inputString("> Item : ");
		int command2 = KeyboardUtil.inputNumber("> Quantity : ");

		return command1 + "/" + command2;
	}

	@Override
	public boolean control(String command) {
		// TODO 냉장고 제어를 실행하는 코드를 작성하시오
		if (command != null) {
			String[] items = command.split("/");
			System.out.println("items: " + items[0] + " / " + items[1]);

			FridgeItem fi = new FridgeItem();
			fi.setName(items[0]);
			fi.setQuantity(Integer.parseInt(items[1]));

			mItems.add(fi);

			return true;
		}

		return false;
	}

}
