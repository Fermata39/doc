package com.lge.entity;

import com.lge.util.KeyboardUtil;

public class Light extends HomeAppliance {

	public static final String TYPE_STRING = Light.class.getSimpleName();

	public static final String COMMAND_TURN_ON = "ON"; // ON 명령어
	public static final String COMMAND_TURN_OFF = "OFF"; // OFF 명령어
	public static final String STAUTS_OFF = "OFF"; // ON 상태
	public static final String STAUTS_ON = "ON"; // OFF 상태

	private boolean mIsOn = false; // 현재 전등의 ON/OFF 상태

	public Light(int no) {
		super(no);
	}

	@Override
	public String getStatus() {
		String status = STAUTS_OFF;

		// TODO 전등의 상태를 출력하는 코드를 작성하시오

		if (mIsOn == true) {
			status = COMMAND_TURN_ON;
		} else {
			status = COMMAND_TURN_OFF;
		}

		String res = String.format("%-8s%-15s%-20s", super.mNumber,
				TYPE_STRING, status);

		return res;
	}

	@Override
	public String readUserInput() {
		return KeyboardUtil.inputString("> Control: ON or OFF? ");
	}

	@Override
	public boolean control(String command) {
		// TODO 전등 제어를 실행하는 코드를 작성하시오
		if (command.equals("ON") || command.equals("on")) {
			mIsOn = true;

			return true;
		} else if (command.equals("OFF") || command.equals("off")) {
			mIsOn = false;
			return true;
		}
		return false;
	}
}
