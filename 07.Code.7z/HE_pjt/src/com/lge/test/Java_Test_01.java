package com.lge.test;

import java.util.List;

import com.lge.entity.HomeAppliance;
import com.lge.service.HomeNetService;
import com.lge.util.KeyboardUtil;

public class Java_Test_01 {

	/**
	 * �봽濡쒓렇�옩 �떆�옉 硫붿꽌�뱶
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		HomeNetService service = new HomeNetService();
		int sel;
		while (true) {
			sel = displayMenu();
			if (sel == 0)
				break;
			switch (sel) {
			case 1:
				retrieveHomeAppliances(service);
				break;
			case 2:
				addHomeAppliance(service);
				break;
			case 3:
				removeHomeAppliance(service);
				break;
			case 4:
				controlHomeAppliance(service);
				break;
			default:
				System.out.println(":: Invalid menu number!");
				break;
			}
		}
		System.out.println("finish");
		System.exit(0);
	}

	/**
	 * �궗�슜�옄媛� �엯�젰�븳 硫붾돱�쓽 媛믪쓣 媛��졇�삩�떎.
	 * 
	 * @return �궗�슜�옄 �엯�젰 硫붾돱 媛�
	 */
	private static int displayMenu() {
		System.out.println("\n===============================================");
		System.out.println("        Home Network System");
		System.out.println("===============================================");
		System.out.println("1. Retrieve home appliances ");
		System.out.println("2. Add a home appliance");
		System.out.println("3. Remove a home appliance ");
		System.out.println("4. Control a home appliance ");
		System.out.println("0. Exit");
		System.out.print(">> Select menu : ");
		int sel = KeyboardUtil.inputNumber();

		return sel;
	}

	/**
	 * 媛��쟾湲곌린瑜� �몴�떆�븳�떎.
	 * 
	 * @param service
	 *            �꽌鍮꾩뒪 媛앹껜
	 */
	private static void retrieveHomeAppliances(HomeNetService service) {
		List<HomeAppliance> gList = service.getHomeAppliances();
		if (gList.size() < 1) {
			System.out.println(":: There is no home appliances!");
			return;
		}

		System.out.println(String.format("\n%-8s%-15s%-20s", "No.", "Name",
				"Status"));
		System.out.println("------------------------------------------------");
		for (HomeAppliance g : gList) {
			if (g == null) {
				continue;
			} else {
				System.out.println(g.getStatus());
			}
		}
	}

	/**
	 * 媛��쟾湲곌린瑜� 異붽��븳�떎.
	 * 
	 * @param service
	 *            �꽌鍮꾩뒪 媛앹껜
	 */
	private static void addHomeAppliance(HomeNetService service) {
		String type = KeyboardUtil.inputString("\n>Type : ");

		boolean isSuccess = service.addHomeAppliance(type);

		if (isSuccess) {
			System.out.println(":: Success!");
		} else {
			System.out.println(":: Invalid type!");
		}

	}

	/**
	 * 媛��쟾湲곌린瑜� �젣嫄고븳�떎.
	 * 
	 * @param service
	 *            �꽌鍮꾩뒪 媛앹껜
	 */
	private static void removeHomeAppliance(HomeNetService service) {
		int no = KeyboardUtil.inputNumber("\n> Select no : ");
		boolean isSuccess = service.removeHomeAppliance(no);

		if (isSuccess) {
			System.out.println(":: Success!");
		} else {
			System.out.println(":: Invalid No!");
		}
	}

	/**
	 * 媛��쟾湲곌린瑜� �젣�뼱�븳�떎.
	 * 
	 * @param service
	 *            �꽌鍮꾩뒪 媛앹껜
	 */
	private static void controlHomeAppliance(HomeNetService service) {
		int no = KeyboardUtil.inputNumber("> Select no : ");
		boolean isSuccess = service.controlHomeAppliance(no);

		if (isSuccess) {
			System.out.println(":: Success!");
		} else {
			System.out.println(":: Invalid control!");
		}
	}
}
