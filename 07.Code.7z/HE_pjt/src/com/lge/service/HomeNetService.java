package com.lge.service;

import java.util.*;

import com.lge.entity.Fridge;
import com.lge.entity.HomeAppliance;
import com.lge.entity.Light;
import com.lge.entity.Television;

public class HomeNetService {

	private Map<Integer, HomeAppliance> mAppliances = new HashMap<Integer, HomeAppliance>();

	private static final char TYPE_STRING_UPPER_F = 'F'; // 냉장고 타입 대문자
	private static final char TYPE_STRING_LOWER_F = 'f'; // 냉장고 타입 소문자
	private static final char TYPE_STRING_UPPER_T = 'T'; // TV 타입 대문자
	private static final char TYPE_STRING_LOWER_T = 't'; // TV 타입 소문자
	private static final char TYPE_STRING_UPPER_L = 'L'; // 전등 타입 대문자
	private static final char TYPE_STRING_LOWER_L = 'l'; // 전등 타입 소문자

	static int number = 105;
	List<HomeAppliance> appliancesTemp;

	public HomeNetService() {
		HomeAppliance s01 = new Fridge(101);
		HomeAppliance s02 = new Fridge(102);
		HomeAppliance s03 = new Television(103);
		HomeAppliance s04 = new Light(104);

		mAppliances.put(101, s01);
		mAppliances.put(102, s02);
		mAppliances.put(103, s03);
		mAppliances.put(104, s04);

	}

	/**
	 * 가전 기기를 추가한다.
	 * 
	 * @param type
	 *            가전기기 타입
	 * @return 성공여부
	 */
	public boolean addHomeAppliance(String type) {
		int newNumber = getNextApplianceNumber();
		System.out.println("newNumber: " + newNumber);
		// TODO 입력받은 type에 맞는 가전기기를 추가하는 코드를 작성하시오
		if (type.equals(Character.toString(TYPE_STRING_UPPER_F))) {
			HomeAppliance uF = new Fridge(newNumber);
			mAppliances.put(newNumber, uF);
			System.out.println("test: " + mAppliances.keySet());
			return true;
		} else if (type.equals(Character.toString(TYPE_STRING_LOWER_F))) {
			HomeAppliance lF = new Fridge(newNumber);
			mAppliances.put(newNumber, lF);
			return true;
		} else if (type.equals(Character.toString(TYPE_STRING_UPPER_T))) {
			HomeAppliance uT = new Television(newNumber);
			mAppliances.put(newNumber, uT);
			return true;
		} else if (type.equals(Character.toString(TYPE_STRING_LOWER_T))) {
			HomeAppliance lT = new Television(newNumber);
			mAppliances.put(newNumber, lT);
			return true;
		} else if (type.equals(Character.toString(TYPE_STRING_UPPER_L))) {
			HomeAppliance uL = new Light(newNumber);
			mAppliances.put(newNumber, uL);
			return true;
		} else if (type.equals(Character.toString(TYPE_STRING_LOWER_L))) {
			HomeAppliance lL = new Light(newNumber);
			mAppliances.put(newNumber, lL);
			return true;
		} else {
			System.out.println("No type: " + newNumber);
			if (number > 104) {
				number--;
			}
			return false;
		}
	}

	/**
	 * 신규 가전기기의 번호를 구한다.
	 * 
	 * @return 신규 가전기기 번호
	 */
	private int getNextApplianceNumber() {
		// TODO 새 가전기기 추가시 일련번호를 리턴한다.

		return number++;
	}

	/**
	 * 번호 순으로 가전 기기 목록을 가져온다
	 * 
	 * @return 가전기기 List
	 */
	public List<HomeAppliance> getHomeAppliances() {
		List<HomeAppliance> res = new ArrayList<HomeAppliance>();
		// TODO 번호순으로 정렬하여 가전기기 목록을 리턴하는 코드를 작성하시오.
		//

		Iterator<Integer> key = mAppliances.keySet().iterator();
		Integer number;
		while (key.hasNext()) {
			number = key.next();
			res.add(mAppliances.get(number));
		}
		return res;
	}

	/**
	 * 가전기기를 제거한다.
	 * 
	 * @param no
	 *            가전기기 번호
	 * @return 성공 여부
	 */
	public boolean removeHomeAppliance(int no) {
		List<HomeAppliance> appliances = getHomeAppliances();
		// TODO 가전기기를 제거하는 코드를 작성하시오
		System.out.println("removeHomeAppliance-enter no: " + no);
		System.out.println("appliances: " + appliances.size());
		System.out.println("mAppliances.get(no): " + mAppliances.get(no));
		boolean flag = false;
		for (int i = 0; i < appliances.size(); i++) {
			System.out.println("element list[" + i + "]: " + appliances.get(i));
			if (appliances.get(i) == null) {
				continue;
			} else if (appliances.get(i).equals(mAppliances.get(no))) {
				System.out.println("found element1: " + appliances.get(i)
						+ "no: " + no);
				mAppliances.remove(no);
				flag = true;
			}
		}
		return flag;
	}

	/**
	 * 가전 기기를 제어한다
	 */
	public boolean controlHomeAppliance(int no) {
		HomeAppliance appliance = mAppliances.get(no);

		if (appliance == null) {
			return false;
		}

		System.out.println(appliance.getStatus());

		if (mAppliances.containsKey(no)) {
			String command = appliance.readUserInput();
			boolean isSuccess = appliance.control(command);

			return isSuccess;
		}

		return false;
	}

}
