package com.lge.lang;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class NumIgnoreString {

	private String str;

	public NumIgnoreString(String str) {

		this.str = str;
	}

	public static String ReturnNumIgnoreString(String str) {

		List<String> list = new ArrayList<String>();
		int[] NumA = new int[str.length()];
		String[] StringA = new String[str.length()];
		String ch = "";

		for (int i = 0; i < str.length(); i++) {
			ch = Character.toString(str.charAt(i));
			if (ch.matches("[0-9]")) { // 문자열 중에 숫자가 있는지 검사
				NumA[i] = Integer.parseInt(ch); // 숫자면 숫자배열에 넣음
				StringA[i] = ""; // 비어 있는 부분은 " "으로
			} else {
				StringA[i] = ch; // 숫자가 아니면 문자를 문자배열에 넣음
			}
		}

		String temp = "";
		for (int i = 0; i < StringA.length; i++) {
			temp += StringA[i];

		}

		System.out.println("str: " + temp.trim()); // 배열안에 공백들을 제거

		return temp;
	}

	/**
	 * Causes this character sequence to be replaced by the reverse of the
	 * sequence based on ignoring numbers.
	 * 
	 * @return revered string
	 */
	public String reverse() {

		// TODO : Write code here
		// System.out.println("before print: " + str);

		Stack<String> st = new Stack<String>();
		String ch = "";

		int[] numA = new int[str.length()];
		String[] stringA = new String[str.length()];
		List<String> list = new ArrayList<String>();

		for (int i = 0; i < str.length(); i++) {
			ch = Character.toString(str.charAt(i));
			// System.out.println("ch: " + ch);
			if (ch.matches("[0-9]")) {
				// System.out.println("number");
				numA[i] = Integer.parseInt(ch); // str 검색중에 숫자가 나오면 숫자 배열로
				// System.out.println("numA[" + i + "]:" + numA[i]);
			} else {
				stringA[i] = ch; // 숫자가 아니면 string 배열로
				list.add(ch); // reverse 수행
			}
		}

		String afterCh = "";

		Collections.reverse(list); // list 에 넣은 요소를 reverse

		for (int j = 0; j < numA.length; j++) {
			if (numA[j] != 0) {
				// System.out.println("[" + j + "]");
				list.add(j, Integer.toString(numA[j]));
			} else {
				continue;
			}
		}

		// System.out.print("after list: ");
		for (String s : list) {
			// System.out.print(s);
			afterCh += s;
		}
		System.out.println();

		return afterCh;
	}
}