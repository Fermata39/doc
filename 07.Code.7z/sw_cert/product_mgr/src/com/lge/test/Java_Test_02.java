package com.lge.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

import com.lge.exception.ProductDuplicateException;
import com.lge.exception.ProductNotFoundException;
import com.lge.model.Product;
import com.lge.model.ProductDao;

public class Java_Test_02 {

	public static void main(String[] args) {
		while (true) {
			int menu = displayMenu();
			System.out.println();
			switch (menu) {
			case 1:
				printAllProducts();
				break;
			case 2:
				insert();
				break;
			case 3:
				changeStock();
				break;
			case 4:
				search();
				break;
			case 5:
				delete();
				break;
			case 0:
				return;
			default:
				System.out.println(":: Invalid menu number!");
				break;
			}
		}
	}

	private static int displayMenu() {
		System.out.println("\n===============================================");
		System.out.println("          Product Management System");
		System.out.println("===============================================");
		System.out.println("1. Retrieve all products");
		System.out.println("2. Add a product");
		System.out.println("3. Change quantity");
		System.out.println("4. Search products");
		System.out.println("5. Remove a product");
		System.out.println("0. Exit");
		System.out.print(">> Select menu : ");

		Scanner in = new Scanner(System.in);
		return in.nextInt();
	}

	/**
	 * Printing a product's information
	 */
	public static void printProduct(Product p) {
		int quantity = 0;
		try {
			quantity = ProductDao.getInstance().getQuantity(p.getCode());
			System.out.println(p + " | " + quantity + "EA");
		} catch (ProductNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * Printing all the product's information
	 */
	private static void printAllProducts() {
		HashMap<Product, Integer> pMap = ProductDao.getInstance()
				.getProductMap();
		Iterator<Product> keys = pMap.keySet().iterator();
		while (keys.hasNext()) {
			printProduct(keys.next());
		}
	}

	/**
	 * Registering new product
	 */
	private static void insert() {

		Scanner in = new Scanner(System.in);

		Product newProduct = new Product();

		System.out.print("> Product code : ");
		String code = in.nextLine();
		newProduct.setCode(code);

		System.out.print("> Name : ");
		String name = in.nextLine();
		newProduct.setName(name);

		System.out.print("> Quantity : ");
		int quantity = in.nextInt();

		System.out.print("> Price : ");
		int price = in.nextInt();
		newProduct.setPrice(price);

		// TODO : Write code here

		// Use code below, if necessary

		ProductDao dao = ProductDao.getInstance();
		try {
			dao.addProduct(newProduct, quantity);
		} catch (ProductDuplicateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(":: Success!");
		printProduct(newProduct);
	}

	/**
	 * Getting the product containing search key in name
	 */
	private static void search() {
		Scanner in = new Scanner(System.in);
		System.out.print("> Name : ");
		String key = in.next();

		// TODO : Write code here

		// Use code below, if necessary
		ProductDao dao = ProductDao.getInstance();
		ArrayList<Product> result = dao.searchProduct(key);
		System.out.println(":: The product name does not exist!");
		// printProduct(product);
	}

	/**
	 * Changing quantity of a product containing entered code
	 */
	private static void changeStock() {
		Scanner in = new Scanner(System.in);
		System.out.print("> Product code : ");
		String code = in.next();
		System.out.print("> Quantity : ");
		int quantity = in.nextInt();

		// TODO : Write code here

		// Use code below, if necessary

		// ProductDao dao = ProductDao.getInstance();
		// Product p = dao.getProduct(code);
		// dao.changeQuantity(code, quantity);
		// printProduct(p);
		// System.out.println(":: Success!");

	}

	/**
	 * Deleting a product in ProductDao
	 */
	private static void delete() {
		Scanner in = new Scanner(System.in);
		System.out.print("> Product code : ");
		String key = in.next();

		// TODO : Write code here

		// Use code below, if necessary

		// ProductDao dao = ProductDao.getInstance();
		// dao.delete(key);
		// System.out.println(":: Success!");
	}
}