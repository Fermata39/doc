package com.lge.model;

import com.lge.util.Utilities;

public class Product implements Comparable<Product> {
	private String code;
	private String name;
	private int price;

	public Product() {
	}

	public Product(String code, String name, int price) {
		this.code = code;
		this.name = name;
		this.price = price;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getPrice() {
		return price;
	}

	public boolean equals(Object obj) {
		if (obj != null && obj instanceof Product) {
			if (code == ((Product) obj).getCode())
				return true;
		}
		return false;
	}

	public int hashCode() {
		return code.hashCode();
	}

	@Override
	public String toString() {
		StringBuffer info = new StringBuffer();
		info.append(code).append(" | ");
		info.append(name).append(" | ");
		info.append(Utilities.convertCurrencyFormat(price));
		return info.toString();
	}

	@Override
	public int compareTo(Product arg0) {
		return this.code.compareTo(arg0.code);
	}

}