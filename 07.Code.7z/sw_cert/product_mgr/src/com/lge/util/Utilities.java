package com.lge.util;

import java.text.NumberFormat;
import java.util.Locale;

// Class for common function
public class Utilities {

	/**
	 * Convert value to KOREAN currency string
	 */
	public static String convertCurrencyFormat(double data) {
		return NumberFormat.getCurrencyInstance(Locale.KOREA).format(data);
	}
}