package com.lge.exception;

/** Thrown to indicate that a product's out of stock */
@SuppressWarnings("serial")
public class ProductOutOfStockException extends Exception {
    public ProductOutOfStockException(String message) {
        super(message);
    }

    public ProductOutOfStockException() {
        super(":: Out of stock!");
    }
}