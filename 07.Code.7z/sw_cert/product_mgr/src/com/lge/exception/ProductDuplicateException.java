package com.lge.exception;

/** Thrown to indicate that a product already exists in ProductDao */
@SuppressWarnings("serial")
public class ProductDuplicateException extends Exception {
    public ProductDuplicateException(String message) {
        super(message);
    }

    public ProductDuplicateException() {
        this(":: The product code already exists!");
    }
}