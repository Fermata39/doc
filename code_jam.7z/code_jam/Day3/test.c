
#include <stdio.h>
#include "stdafx.h"
#include <stdlib.h>
#include <math.h>
enum a {
 NEAR = 0,
 FAR,
 SAME
};
int _tmain(int argc, _TCHAR* argv[]) {
 int num_tc = 0;
 int max_num = 0, num_query = 0;
 int now = 0, prev = 0, answer = 0, far = 0, near = 0;
 int start = 0, end = 0, start_tmp = 0, end_tmp = 0;
 int i = 0, j = 0;
 FILE * f = NULL, *out = NULL; 
 _wfopen_s(&f, L"D:\\01.Project\\00.Task\\codejam2\\Debug\\LData001.in", L"r");
 _wfopen_s(&out, L"D:\\01.Project\\00.Task\\codejam2\\Debug\\eunchul.txt", L"w+");
 fscanf(f, "%d", &num_tc);
  
 while(i++ != num_tc) {
  fscanf(f, "%d %d", &max_num, &num_query);
  j = 0;
  start_tmp = start = 1;
  end_tmp = end = max_num;
  while(j++ != num_query) {
   fscanf(f, "%d %d", &now, &answer);
   //fprintf(out, "now %d answer %d\n", now, answer);
    
   if(j == 1) {
    prev = now;
    continue;
   }
   near = far = 0;
   switch(answer) {
    case NEAR:
     near = now;
     far = prev;
     break;
    case FAR:
     near = prev;
     far = now;
     break;
    case SAME:
     if(prev > now) {
      start = now + (prev - now) / 2;
      end = start;
     } else if(now > prev) {
      start = prev + (now - prev) / 2;
      end = start;
     }
     fprintf(out, "%d ", end - start + 1);
      
     break;
   }
   prev = now;
   if(answer == SAME) continue;
   if(near > far) {
    start_tmp = (int)(far + (near - far) / 2) + 1;
   } else if(far > near) {
    end_tmp = ceil(near + (double)(far - near) /2 ) - 1;
   }
   if(!(start > end_tmp || end < start_tmp)) {
     
    if(start < start_tmp) start = start_tmp;
    if(end > end_tmp) end = end_tmp;
   }
   //fprintf(out, "start %d end %d\n", start, end);
   fprintf(out, "%d ", end - start + 1);
   fflush(stdin);
  }
  fprintf(out, "\n");
 }
}